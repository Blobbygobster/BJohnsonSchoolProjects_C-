﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Johnson_Assignment6
{
    class Account //Base class for instance variables and Credit/Debit formulas.
    {
        private decimal Balance; 
        private string AccountName;
        private int AccountNumber;


        public Account(decimal balance, string name, int number) //Constructor for Balance, AccountName, and AccountNumber.
        {
            this.Balance = balance;
            this.AccountName = name;
            this.AccountNumber = number;
        }
        public void setBalance(decimal balance) //Balance setter, validating if balance is greater than 0.
        {

            if (balance > 0.0m)
                Balance = balance;
            else
                Balance = 0;       
        }

        public decimal getBalance() //Balance get method
        {
            return this.Balance;
        }

        public void setAccountName(string name) 
        {
            this.AccountName = name;
        }

        public string getAccountName() 
        {
            return this.AccountName;
        }

        public void setAccountNumber(int number)
        {
            this.AccountNumber = number;
        }

        public int getAccountNumber()
        {
            return this.AccountNumber;
        }


        public virtual void Credit(decimal cred) //Method Credit adds to current amount on account
        {

            this.Balance += cred;
        }
       
        public virtual bool Debit(decimal deb) //Method Debit withdraws from account
        {

            if (deb > Balance) //If-else detects if account is able to withdraw money. Returns line if withdraw exceeds amount
            {
                Console.WriteLine("Insufficient Funds");
                return false;
            }

            else
            {
                this.Balance -= deb;
                return true;
            }
              

        }

        public virtual void PrintAccount() //This method will return the information when called upon
        {
            Console.WriteLine("Account Name: " + this.AccountName);
            Console.WriteLine("Account Number: " + this.AccountNumber);
            Console.WriteLine("Balance: " + this.Balance.ToString("C"));
        }
        
   
    }

    class SavingsAccount : Account //Derived class inherits functionality of Account
    {
        private decimal InterestRate;

        public SavingsAccount(string name, int number, decimal balance, decimal interestRate) : base(balance, name, number)
        {
            this.setInterestRate(interestRate); //SavingsAccount constructor, calls upon base constructor for balance, name, and number

        }

        public void setInterestRate(decimal interestRate) //setter makes interest rate 0 if number is negative
        {
            if (interestRate < 0.0m)
            {
                this.InterestRate = 0;

            }
            else
            {
                this.InterestRate = interestRate;
            }
            
            
        }

        public decimal CalculateInterest() //Calculates interest rate
        {
            return base.getBalance() * this.InterestRate;
        }

        public override void PrintAccount()
        {
            base.PrintAccount();
            Console.WriteLine("Interest Rate: " + this.InterestRate.ToString("P"));
        }

            
    }

    class CheckingAccount : Account //Derived class inherits from base class
    {
        private decimal FeeCharged; //Creates FeeCharged variable

        public CheckingAccount(string name, int number, decimal balance, decimal feeAmount) : base(balance, name, number) //Constructor for CheckingAccount, calls upon base constructor like SavingsAccount
        {
            this.setFeeAmount(feeAmount); 
            
        }

        public void setFeeAmount(decimal feeAmount) //Setter operates much like interest rate, where negative is made into 0
        {
            if (feeAmount < 0.0m)
            {
                this.FeeCharged = 0;
            }

            else
            {
                this.FeeCharged = feeAmount;
            }
        }

        public override void Credit(decimal reCred) //Method Redefines Credit with successful transaction, updates balance
        {
            base.Credit(reCred);
            ChargeFee();
         
        }
         
        public override bool Debit(decimal reDeb) //Method Redefines Debit with successful transaction, withdraws money 
        {
            if (base.Debit(reDeb))
            {
                ChargeFee();
                return true;
            }
            else
            {
                return false;
            }
        }

        public void ChargeFee() //Charge fee subtracts transaction fee
        {
            base.setBalance(base.getBalance() - this.FeeCharged);
            Console.WriteLine(this.FeeCharged.ToString("C") + "transaction fee charges. ");
        }

        public override void PrintAccount()
        {
            base.PrintAccount();
            Console.WriteLine("FeeCharged: " + this.FeeCharged.ToString("C"));
        }

    }

    class Application
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("|| This program was written by Brandon Johnson for CSIS 209-D01 ||");
            Console.WriteLine();

            CheckingAccount JohnsonChecking = new CheckingAccount("Johnson-Checking", 1, 1000, 3.00m); //These two lines create the checking and savings accounts with their respective information
            Console.WriteLine("Created checking account with $1,000 balance.");
            SavingsAccount JohnsonSavings = new SavingsAccount("Johnson-Savings", 2, 2000, 0.05m);
            Console.WriteLine("Created savings account with $2,000 balance");

            JohnsonChecking.PrintAccount(); //These two lines print their respective account information
            Console.WriteLine();
            JohnsonSavings.PrintAccount();
            Console.WriteLine();

            Console.WriteLine("Deposit $100 into checking."); //Tests deposit of $100 into checking, and returns info
            JohnsonChecking.Credit(100);
            JohnsonChecking.PrintAccount();
            Console.WriteLine();

            Console.WriteLine("Withdraw $50 from checking."); //Tests withdrawl of $50 from checking, returns info
            JohnsonChecking.Debit(50);
            JohnsonChecking.PrintAccount();
            Console.WriteLine();

            Console.WriteLine("Withdraw $6,000 from checking."); //Tests Insufficent Funds return when withdrawing over limit, returns message and account info
            JohnsonChecking.Debit(6000);
            JohnsonChecking.PrintAccount();
            Console.WriteLine();

            Console.WriteLine("Deposit $3,000 into savings."); //Tests deposit into savings, returns info
            JohnsonSavings.Credit(3000);
            JohnsonSavings.PrintAccount();
            Console.WriteLine();

            Console.WriteLine("Withdraw $200 from savings."); //Tests withdrawl from savings, returns info
            JohnsonSavings.Debit(200);
            JohnsonSavings.PrintAccount();
            Console.WriteLine();

            Console.WriteLine("Calculate Interest on savings."); //Calculates interest on savings account according to current info, returns info
            decimal interest = JohnsonSavings.CalculateInterest();
            JohnsonSavings.Credit(interest);
            JohnsonSavings.PrintAccount();
            Console.WriteLine();

            Console.WriteLine("Withdraw $10,000 from savings"); //Tests Insufficient funds return when withdrawing over limit, returns info
            JohnsonSavings.Debit(10000);
            JohnsonSavings.PrintAccount();
            Console.WriteLine();

            Console.WriteLine("Press the [Enter] key to continue.");
            Console.ReadKey();




        }
    }
}
