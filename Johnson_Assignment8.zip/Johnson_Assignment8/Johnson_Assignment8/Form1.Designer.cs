﻿namespace Johnson_Assignment8
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.buttonSubmit = new System.Windows.Forms.Button();
            this.buttonExit = new System.Windows.Forms.Button();
            this.dayTuesday = new System.Windows.Forms.Label();
            this.dayWednesday = new System.Windows.Forms.Label();
            this.dayThursday = new System.Windows.Forms.Label();
            this.dayFriday = new System.Windows.Forms.Label();
            this.daySaturday = new System.Windows.Forms.Label();
            this.daySunday = new System.Windows.Forms.Label();
            this.dayMonday = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.sundayCheck = new System.Windows.Forms.CheckBox();
            this.saturdayCheck = new System.Windows.Forms.CheckBox();
            this.fridayCheck = new System.Windows.Forms.CheckBox();
            this.thursdayCheck = new System.Windows.Forms.CheckBox();
            this.wednesdayCheck = new System.Windows.Forms.CheckBox();
            this.tuesdayCheck = new System.Windows.Forms.CheckBox();
            this.mondayCheck = new System.Windows.Forms.CheckBox();
            this.hourBox7B = new System.Windows.Forms.TextBox();
            this.hourBox6B = new System.Windows.Forms.TextBox();
            this.hourBox5B = new System.Windows.Forms.TextBox();
            this.hourBox4B = new System.Windows.Forms.TextBox();
            this.hourBox3B = new System.Windows.Forms.TextBox();
            this.hourBox2B = new System.Windows.Forms.TextBox();
            this.hourBox1B = new System.Windows.Forms.TextBox();
            this.hourBox7A = new System.Windows.Forms.TextBox();
            this.hourBox6A = new System.Windows.Forms.TextBox();
            this.hourBox5A = new System.Windows.Forms.TextBox();
            this.hourBox4A = new System.Windows.Forms.TextBox();
            this.hourBox3A = new System.Windows.Forms.TextBox();
            this.hourBox2A = new System.Windows.Forms.TextBox();
            this.hourBox1A = new System.Windows.Forms.TextBox();
            this.supervisorName = new System.Windows.Forms.Label();
            this.supervisorBox = new System.Windows.Forms.TextBox();
            this.client = new System.Windows.Forms.Label();
            this.contract = new System.Windows.Forms.Label();
            this.project = new System.Windows.Forms.Label();
            this.clientNameA = new System.Windows.Forms.TextBox();
            this.contractA = new System.Windows.Forms.TextBox();
            this.projectA = new System.Windows.Forms.TextBox();
            this.clientNameB = new System.Windows.Forms.TextBox();
            this.contractB = new System.Windows.Forms.TextBox();
            this.projectB = new System.Windows.Forms.TextBox();
            this.reportingWeek = new System.Windows.Forms.Label();
            this.specialCheckBox = new System.Windows.Forms.Label();
            this.numericReportWeek = new System.Windows.Forms.NumericUpDown();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericReportWeek)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(23, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name";
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(27, 53);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(405, 26);
            this.nameBox.TabIndex = 1;
            // 
            // buttonSubmit
            // 
            this.buttonSubmit.Location = new System.Drawing.Point(362, 662);
            this.buttonSubmit.Name = "buttonSubmit";
            this.buttonSubmit.Size = new System.Drawing.Size(85, 30);
            this.buttonSubmit.TabIndex = 2;
            this.buttonSubmit.Text = "Submit";
            this.buttonSubmit.UseVisualStyleBackColor = true;
            this.buttonSubmit.Click += new System.EventHandler(this.buttonSubmit_Click);
            // 
            // buttonExit
            // 
            this.buttonExit.Location = new System.Drawing.Point(511, 662);
            this.buttonExit.Name = "buttonExit";
            this.buttonExit.Size = new System.Drawing.Size(71, 30);
            this.buttonExit.TabIndex = 3;
            this.buttonExit.Text = "Exit";
            this.buttonExit.UseVisualStyleBackColor = true;
            this.buttonExit.Click += new System.EventHandler(this.buttonExit_Click);
            // 
            // dayTuesday
            // 
            this.dayTuesday.AutoSize = true;
            this.dayTuesday.BackColor = System.Drawing.SystemColors.Window;
            this.dayTuesday.Location = new System.Drawing.Point(71, 0);
            this.dayTuesday.Name = "dayTuesday";
            this.dayTuesday.Size = new System.Drawing.Size(69, 20);
            this.dayTuesday.TabIndex = 5;
            this.dayTuesday.Text = "Tuesday";
            // 
            // dayWednesday
            // 
            this.dayWednesday.AutoSize = true;
            this.dayWednesday.BackColor = System.Drawing.SystemColors.Window;
            this.dayWednesday.Location = new System.Drawing.Point(146, 0);
            this.dayWednesday.Name = "dayWednesday";
            this.dayWednesday.Size = new System.Drawing.Size(93, 20);
            this.dayWednesday.TabIndex = 6;
            this.dayWednesday.Text = "Wednesday";
            // 
            // dayThursday
            // 
            this.dayThursday.AutoSize = true;
            this.dayThursday.BackColor = System.Drawing.SystemColors.Window;
            this.dayThursday.Location = new System.Drawing.Point(245, 0);
            this.dayThursday.Name = "dayThursday";
            this.dayThursday.Size = new System.Drawing.Size(74, 20);
            this.dayThursday.TabIndex = 7;
            this.dayThursday.Text = "Thursday";
            // 
            // dayFriday
            // 
            this.dayFriday.AutoSize = true;
            this.dayFriday.BackColor = System.Drawing.SystemColors.Window;
            this.dayFriday.Location = new System.Drawing.Point(325, 0);
            this.dayFriday.Name = "dayFriday";
            this.dayFriday.Size = new System.Drawing.Size(52, 20);
            this.dayFriday.TabIndex = 8;
            this.dayFriday.Text = "Friday";
            // 
            // daySaturday
            // 
            this.daySaturday.AutoSize = true;
            this.daySaturday.BackColor = System.Drawing.SystemColors.Window;
            this.daySaturday.Location = new System.Drawing.Point(383, 0);
            this.daySaturday.Name = "daySaturday";
            this.daySaturday.Size = new System.Drawing.Size(73, 20);
            this.daySaturday.TabIndex = 9;
            this.daySaturday.Text = "Saturday";
            // 
            // daySunday
            // 
            this.daySunday.AutoSize = true;
            this.daySunday.BackColor = System.Drawing.SystemColors.Window;
            this.daySunday.Location = new System.Drawing.Point(462, 0);
            this.daySunday.Name = "daySunday";
            this.daySunday.Size = new System.Drawing.Size(63, 20);
            this.daySunday.TabIndex = 10;
            this.daySunday.Text = "Sunday";
            // 
            // dayMonday
            // 
            this.dayMonday.AutoSize = true;
            this.dayMonday.BackColor = System.Drawing.SystemColors.Window;
            this.dayMonday.Location = new System.Drawing.Point(0, 0);
            this.dayMonday.Name = "dayMonday";
            this.dayMonday.Size = new System.Drawing.Size(65, 20);
            this.dayMonday.TabIndex = 11;
            this.dayMonday.Text = "Monday";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.sundayCheck);
            this.panel1.Controls.Add(this.saturdayCheck);
            this.panel1.Controls.Add(this.fridayCheck);
            this.panel1.Controls.Add(this.thursdayCheck);
            this.panel1.Controls.Add(this.wednesdayCheck);
            this.panel1.Controls.Add(this.tuesdayCheck);
            this.panel1.Controls.Add(this.mondayCheck);
            this.panel1.Controls.Add(this.hourBox7B);
            this.panel1.Controls.Add(this.hourBox6B);
            this.panel1.Controls.Add(this.hourBox5B);
            this.panel1.Controls.Add(this.hourBox4B);
            this.panel1.Controls.Add(this.hourBox3B);
            this.panel1.Controls.Add(this.hourBox2B);
            this.panel1.Controls.Add(this.hourBox1B);
            this.panel1.Controls.Add(this.hourBox7A);
            this.panel1.Controls.Add(this.hourBox6A);
            this.panel1.Controls.Add(this.hourBox5A);
            this.panel1.Controls.Add(this.hourBox4A);
            this.panel1.Controls.Add(this.hourBox3A);
            this.panel1.Controls.Add(this.hourBox2A);
            this.panel1.Controls.Add(this.hourBox1A);
            this.panel1.Controls.Add(this.dayMonday);
            this.panel1.Controls.Add(this.daySaturday);
            this.panel1.Controls.Add(this.daySunday);
            this.panel1.Controls.Add(this.dayTuesday);
            this.panel1.Controls.Add(this.dayWednesday);
            this.panel1.Controls.Add(this.dayFriday);
            this.panel1.Controls.Add(this.dayThursday);
            this.panel1.Location = new System.Drawing.Point(436, 397);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(527, 141);
            this.panel1.TabIndex = 12;
            // 
            // sundayCheck
            // 
            this.sundayCheck.AutoSize = true;
            this.sundayCheck.Location = new System.Drawing.Point(487, 116);
            this.sundayCheck.Name = "sundayCheck";
            this.sundayCheck.Size = new System.Drawing.Size(22, 21);
            this.sundayCheck.TabIndex = 34;
            this.sundayCheck.UseVisualStyleBackColor = true;
            // 
            // saturdayCheck
            // 
            this.saturdayCheck.AutoSize = true;
            this.saturdayCheck.Location = new System.Drawing.Point(409, 116);
            this.saturdayCheck.Name = "saturdayCheck";
            this.saturdayCheck.Size = new System.Drawing.Size(22, 21);
            this.saturdayCheck.TabIndex = 33;
            this.saturdayCheck.UseVisualStyleBackColor = true;
            // 
            // fridayCheck
            // 
            this.fridayCheck.AutoSize = true;
            this.fridayCheck.Location = new System.Drawing.Point(344, 116);
            this.fridayCheck.Name = "fridayCheck";
            this.fridayCheck.Size = new System.Drawing.Size(22, 21);
            this.fridayCheck.TabIndex = 32;
            this.fridayCheck.UseVisualStyleBackColor = true;
            // 
            // thursdayCheck
            // 
            this.thursdayCheck.AutoSize = true;
            this.thursdayCheck.Location = new System.Drawing.Point(274, 116);
            this.thursdayCheck.Name = "thursdayCheck";
            this.thursdayCheck.Size = new System.Drawing.Size(22, 21);
            this.thursdayCheck.TabIndex = 31;
            this.thursdayCheck.UseVisualStyleBackColor = true;
            // 
            // wednesdayCheck
            // 
            this.wednesdayCheck.AutoSize = true;
            this.wednesdayCheck.Location = new System.Drawing.Point(179, 116);
            this.wednesdayCheck.Name = "wednesdayCheck";
            this.wednesdayCheck.Size = new System.Drawing.Size(22, 21);
            this.wednesdayCheck.TabIndex = 30;
            this.wednesdayCheck.UseVisualStyleBackColor = true;
            // 
            // tuesdayCheck
            // 
            this.tuesdayCheck.AutoSize = true;
            this.tuesdayCheck.Location = new System.Drawing.Point(99, 116);
            this.tuesdayCheck.Name = "tuesdayCheck";
            this.tuesdayCheck.Size = new System.Drawing.Size(22, 21);
            this.tuesdayCheck.TabIndex = 29;
            this.tuesdayCheck.UseVisualStyleBackColor = true;
            // 
            // mondayCheck
            // 
            this.mondayCheck.AutoSize = true;
            this.mondayCheck.Location = new System.Drawing.Point(20, 116);
            this.mondayCheck.Name = "mondayCheck";
            this.mondayCheck.Size = new System.Drawing.Size(22, 21);
            this.mondayCheck.TabIndex = 28;
            this.mondayCheck.UseVisualStyleBackColor = true;
            // 
            // hourBox7B
            // 
            this.hourBox7B.Location = new System.Drawing.Point(466, 56);
            this.hourBox7B.Name = "hourBox7B";
            this.hourBox7B.Size = new System.Drawing.Size(59, 26);
            this.hourBox7B.TabIndex = 27;
            this.hourBox7B.Text = "0";
            this.hourBox7B.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox7B_MouseClick);
            // 
            // hourBox6B
            // 
            this.hourBox6B.Location = new System.Drawing.Point(387, 56);
            this.hourBox6B.Name = "hourBox6B";
            this.hourBox6B.Size = new System.Drawing.Size(69, 26);
            this.hourBox6B.TabIndex = 26;
            this.hourBox6B.Text = "0";
            this.hourBox6B.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox6B_MouseClick);
            this.hourBox6B.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // hourBox5B
            // 
            this.hourBox5B.Location = new System.Drawing.Point(329, 56);
            this.hourBox5B.Name = "hourBox5B";
            this.hourBox5B.Size = new System.Drawing.Size(48, 26);
            this.hourBox5B.TabIndex = 25;
            this.hourBox5B.Text = "0";
            this.hourBox5B.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox5B_MouseClick);
            // 
            // hourBox4B
            // 
            this.hourBox4B.Location = new System.Drawing.Point(249, 56);
            this.hourBox4B.Name = "hourBox4B";
            this.hourBox4B.Size = new System.Drawing.Size(70, 26);
            this.hourBox4B.TabIndex = 24;
            this.hourBox4B.Text = "0";
            this.hourBox4B.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox4B_MouseClick);
            // 
            // hourBox3B
            // 
            this.hourBox3B.Location = new System.Drawing.Point(150, 56);
            this.hourBox3B.Name = "hourBox3B";
            this.hourBox3B.Size = new System.Drawing.Size(86, 26);
            this.hourBox3B.TabIndex = 23;
            this.hourBox3B.Text = "0";
            this.hourBox3B.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox3B_MouseClick);
            // 
            // hourBox2B
            // 
            this.hourBox2B.Location = new System.Drawing.Point(75, 56);
            this.hourBox2B.Name = "hourBox2B";
            this.hourBox2B.Size = new System.Drawing.Size(65, 26);
            this.hourBox2B.TabIndex = 22;
            this.hourBox2B.Text = "0";
            this.hourBox2B.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox2B_MouseClick);
            // 
            // hourBox1B
            // 
            this.hourBox1B.Location = new System.Drawing.Point(0, 57);
            this.hourBox1B.Name = "hourBox1B";
            this.hourBox1B.Size = new System.Drawing.Size(65, 26);
            this.hourBox1B.TabIndex = 21;
            this.hourBox1B.Text = "0";
            this.hourBox1B.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox1B_MouseClick);
            // 
            // hourBox7A
            // 
            this.hourBox7A.Location = new System.Drawing.Point(466, 24);
            this.hourBox7A.Name = "hourBox7A";
            this.hourBox7A.Size = new System.Drawing.Size(59, 26);
            this.hourBox7A.TabIndex = 20;
            this.hourBox7A.Text = "0";
            this.hourBox7A.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox7A_MouseClick);
            // 
            // hourBox6A
            // 
            this.hourBox6A.Location = new System.Drawing.Point(387, 23);
            this.hourBox6A.Name = "hourBox6A";
            this.hourBox6A.Size = new System.Drawing.Size(69, 26);
            this.hourBox6A.TabIndex = 19;
            this.hourBox6A.Text = "0";
            this.hourBox6A.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox6A_MouseClick);
            // 
            // hourBox5A
            // 
            this.hourBox5A.Location = new System.Drawing.Point(329, 23);
            this.hourBox5A.Name = "hourBox5A";
            this.hourBox5A.Size = new System.Drawing.Size(48, 26);
            this.hourBox5A.TabIndex = 18;
            this.hourBox5A.Text = "0";
            this.hourBox5A.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox5A_MouseClick);
            // 
            // hourBox4A
            // 
            this.hourBox4A.Location = new System.Drawing.Point(249, 23);
            this.hourBox4A.Name = "hourBox4A";
            this.hourBox4A.Size = new System.Drawing.Size(70, 26);
            this.hourBox4A.TabIndex = 17;
            this.hourBox4A.Text = "0";
            this.hourBox4A.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox4A_MouseClick);
            // 
            // hourBox3A
            // 
            this.hourBox3A.Location = new System.Drawing.Point(150, 24);
            this.hourBox3A.Name = "hourBox3A";
            this.hourBox3A.Size = new System.Drawing.Size(86, 26);
            this.hourBox3A.TabIndex = 16;
            this.hourBox3A.Text = "0";
            this.hourBox3A.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox3A_MouseClick);
            // 
            // hourBox2A
            // 
            this.hourBox2A.Location = new System.Drawing.Point(75, 23);
            this.hourBox2A.Name = "hourBox2A";
            this.hourBox2A.Size = new System.Drawing.Size(65, 26);
            this.hourBox2A.TabIndex = 15;
            this.hourBox2A.Text = "0";
            this.hourBox2A.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox2A_MouseClick);
            // 
            // hourBox1A
            // 
            this.hourBox1A.Location = new System.Drawing.Point(0, 25);
            this.hourBox1A.Name = "hourBox1A";
            this.hourBox1A.Size = new System.Drawing.Size(65, 26);
            this.hourBox1A.TabIndex = 14;
            this.hourBox1A.Text = "0";
            this.hourBox1A.MouseClick += new System.Windows.Forms.MouseEventHandler(this.hourBox1A_MouseClick);
            // 
            // supervisorName
            // 
            this.supervisorName.AutoSize = true;
            this.supervisorName.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.supervisorName.Location = new System.Drawing.Point(27, 104);
            this.supervisorName.Name = "supervisorName";
            this.supervisorName.Size = new System.Drawing.Size(145, 20);
            this.supervisorName.TabIndex = 13;
            this.supervisorName.Text = "Supervisor Name";
            // 
            // supervisorBox
            // 
            this.supervisorBox.Location = new System.Drawing.Point(31, 150);
            this.supervisorBox.Name = "supervisorBox";
            this.supervisorBox.Size = new System.Drawing.Size(401, 26);
            this.supervisorBox.TabIndex = 14;
            // 
            // client
            // 
            this.client.AutoSize = true;
            this.client.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.client.Location = new System.Drawing.Point(31, 397);
            this.client.Name = "client";
            this.client.Size = new System.Drawing.Size(106, 20);
            this.client.TabIndex = 15;
            this.client.Text = "Client Name";
            // 
            // contract
            // 
            this.contract.AutoSize = true;
            this.contract.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.contract.Location = new System.Drawing.Point(185, 397);
            this.contract.Name = "contract";
            this.contract.Size = new System.Drawing.Size(78, 20);
            this.contract.TabIndex = 16;
            this.contract.Text = "Contract";
            // 
            // project
            // 
            this.project.AutoSize = true;
            this.project.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.project.Location = new System.Drawing.Point(314, 397);
            this.project.Name = "project";
            this.project.Size = new System.Drawing.Size(86, 20);
            this.project.TabIndex = 17;
            this.project.Text = "Project(s)";
            // 
            // clientNameA
            // 
            this.clientNameA.Location = new System.Drawing.Point(35, 421);
            this.clientNameA.Name = "clientNameA";
            this.clientNameA.Size = new System.Drawing.Size(100, 26);
            this.clientNameA.TabIndex = 19;
            this.clientNameA.MouseClick += new System.Windows.Forms.MouseEventHandler(this.clientNameA_MouseClick);
            // 
            // contractA
            // 
            this.contractA.Location = new System.Drawing.Point(189, 421);
            this.contractA.Name = "contractA";
            this.contractA.Size = new System.Drawing.Size(100, 26);
            this.contractA.TabIndex = 20;
            // 
            // projectA
            // 
            this.projectA.Location = new System.Drawing.Point(318, 421);
            this.projectA.Name = "projectA";
            this.projectA.Size = new System.Drawing.Size(100, 26);
            this.projectA.TabIndex = 21;
            // 
            // clientNameB
            // 
            this.clientNameB.Location = new System.Drawing.Point(35, 454);
            this.clientNameB.Name = "clientNameB";
            this.clientNameB.Size = new System.Drawing.Size(100, 26);
            this.clientNameB.TabIndex = 23;
            // 
            // contractB
            // 
            this.contractB.Location = new System.Drawing.Point(189, 454);
            this.contractB.Name = "contractB";
            this.contractB.Size = new System.Drawing.Size(100, 26);
            this.contractB.TabIndex = 24;
            // 
            // projectB
            // 
            this.projectB.Location = new System.Drawing.Point(318, 454);
            this.projectB.Name = "projectB";
            this.projectB.Size = new System.Drawing.Size(100, 26);
            this.projectB.TabIndex = 25;
            // 
            // reportingWeek
            // 
            this.reportingWeek.AutoSize = true;
            this.reportingWeek.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reportingWeek.Location = new System.Drawing.Point(27, 231);
            this.reportingWeek.Name = "reportingWeek";
            this.reportingWeek.Size = new System.Drawing.Size(138, 20);
            this.reportingWeek.TabIndex = 27;
            this.reportingWeek.Text = "Reporting Week";
            // 
            // specialCheckBox
            // 
            this.specialCheckBox.AutoSize = true;
            this.specialCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.specialCheckBox.Location = new System.Drawing.Point(194, 514);
            this.specialCheckBox.Name = "specialCheckBox";
            this.specialCheckBox.Size = new System.Drawing.Size(224, 20);
            this.specialCheckBox.TabIndex = 29;
            this.specialCheckBox.Text = "Weekend/Holiday/Vacation";
            // 
            // numericReportWeek
            // 
            this.numericReportWeek.Location = new System.Drawing.Point(31, 266);
            this.numericReportWeek.Name = "numericReportWeek";
            this.numericReportWeek.Size = new System.Drawing.Size(120, 26);
            this.numericReportWeek.TabIndex = 30;
            this.numericReportWeek.ValueChanged += new System.EventHandler(this.numericReportWeek_ValueChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(981, 704);
            this.Controls.Add(this.numericReportWeek);
            this.Controls.Add(this.specialCheckBox);
            this.Controls.Add(this.reportingWeek);
            this.Controls.Add(this.projectB);
            this.Controls.Add(this.contractB);
            this.Controls.Add(this.clientNameB);
            this.Controls.Add(this.projectA);
            this.Controls.Add(this.contractA);
            this.Controls.Add(this.clientNameA);
            this.Controls.Add(this.project);
            this.Controls.Add(this.contract);
            this.Controls.Add(this.client);
            this.Controls.Add(this.supervisorBox);
            this.Controls.Add(this.supervisorName);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.buttonExit);
            this.Controls.Add(this.buttonSubmit);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericReportWeek)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Button buttonSubmit;
        private System.Windows.Forms.Button buttonExit;
        private System.Windows.Forms.Label dayTuesday;
        private System.Windows.Forms.Label dayWednesday;
        private System.Windows.Forms.Label dayThursday;
        private System.Windows.Forms.Label dayFriday;
        private System.Windows.Forms.Label daySaturday;
        private System.Windows.Forms.Label daySunday;
        private System.Windows.Forms.Label dayMonday;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox hourBox2A;
        private System.Windows.Forms.TextBox hourBox1A;
        private System.Windows.Forms.CheckBox sundayCheck;
        private System.Windows.Forms.CheckBox saturdayCheck;
        private System.Windows.Forms.CheckBox fridayCheck;
        private System.Windows.Forms.CheckBox thursdayCheck;
        private System.Windows.Forms.CheckBox wednesdayCheck;
        private System.Windows.Forms.CheckBox tuesdayCheck;
        private System.Windows.Forms.CheckBox mondayCheck;
        private System.Windows.Forms.TextBox hourBox7B;
        private System.Windows.Forms.TextBox hourBox6B;
        private System.Windows.Forms.TextBox hourBox5B;
        private System.Windows.Forms.TextBox hourBox4B;
        private System.Windows.Forms.TextBox hourBox3B;
        private System.Windows.Forms.TextBox hourBox2B;
        private System.Windows.Forms.TextBox hourBox1B;
        private System.Windows.Forms.TextBox hourBox7A;
        private System.Windows.Forms.TextBox hourBox6A;
        private System.Windows.Forms.TextBox hourBox5A;
        private System.Windows.Forms.TextBox hourBox4A;
        private System.Windows.Forms.TextBox hourBox3A;
        private System.Windows.Forms.Label supervisorName;
        private System.Windows.Forms.TextBox supervisorBox;
        private System.Windows.Forms.Label client;
        private System.Windows.Forms.Label contract;
        private System.Windows.Forms.Label project;
        private System.Windows.Forms.TextBox clientNameA;
        private System.Windows.Forms.TextBox contractA;
        private System.Windows.Forms.TextBox projectA;
        private System.Windows.Forms.TextBox clientNameB;
        private System.Windows.Forms.TextBox contractB;
        private System.Windows.Forms.TextBox projectB;
        private System.Windows.Forms.Label reportingWeek;
        private System.Windows.Forms.Label specialCheckBox;
        private System.Windows.Forms.NumericUpDown numericReportWeek;
    }
}

